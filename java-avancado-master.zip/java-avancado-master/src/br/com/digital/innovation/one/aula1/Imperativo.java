package br.com.digital.innovation.one.aula1;

public class Imperativo {
    public static void main(String[] args) {
        int valor = 10;
        int resultado = valor * 3;
        System.out.println("O resutado é :: "+resultado);
    }
}
