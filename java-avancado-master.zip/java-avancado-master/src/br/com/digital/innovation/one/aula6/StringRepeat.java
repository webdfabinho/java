package br.com.digital.innovation.one.aula6;

public class StringRepeat {
    public static void main(String[] args) {
        String nome = "Joao";
        System.out.println(nome.repeat(10));
    }
}
