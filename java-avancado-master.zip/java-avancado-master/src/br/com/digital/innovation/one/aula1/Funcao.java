package br.com.digital.innovation.one.aula1;

public interface Funcao {
    String gerar(String valor);
}
